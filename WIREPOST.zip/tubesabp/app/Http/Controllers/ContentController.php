<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Category;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use \Cviebrock\EloquentSluggable\Services\SlugService;

class ContentController extends Controller
{
    public function store(Request $request)
    { 
        $inputan = $request->validate([
            'title' => 'required|max:255',
            'slug'=> ['required', 'unique:posts'],
            'category_id'=>'required',
            'image'=>'image|file|max:5120',
            'body' => ['required'] 
        ]);

        if($request->file('image')){
            $inputan['image'] = $request->file('image')->store('img-up');
        }
        $inputan['user_id'] = auth()->user()->id;
        $inputan['excerpt'] = Str::limit(strip_tags($request->body), 200);
        Post::create($inputan);

        return redirect('/upload');
    }

    public function create(){
        return view('upload', [
            'categories' => Category::all()
        ]);

    }

    public function checkSlug(Request $request){
        $slug = SlugService::createSlug(Post::class, 'slug', $request->title);
        return response()->json(['slug' => $slug]);
    }
}
