<?php
 
namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Session;
 
class LoginController extends Controller
{
    public function idx()
    {
        return view('loginpage');
    }
    public function authenticate(Request $request){
        $datainput = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
        
        if (Auth::Attempt($datainput)) {
            $request->session()->regenerate();
            return redirect('/posts');
        }
        else{
            Session::flash('Email atau Password Salah');
            return redirect('/wirepost');
        }
    }
}