<?php
 
namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function store(Request $request)
    {
        $inputan = $request->validate([
            'nama' => 'required|max:255',
            'username' => ['required', 'min:3', 'max:255', 'unique:users'],
            'email'=> ['required', 'min:8', 'unique:users'],
            'password' => ['required', 'min:8', 'max:255'] 
        ]);
        $inputan['password'] = Hash::make($inputan['password']);
        User::create($inputan);

        return redirect('/wirepost');
    }

}