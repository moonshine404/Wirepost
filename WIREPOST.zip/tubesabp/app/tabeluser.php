<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tabeluser extends Model
{
    protected $guarded = ['id'];
}
