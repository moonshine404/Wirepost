<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(Model::class, function (Faker $faker) {
    return [
        'title' => $this->faker->sentence(mt_rand(2,8)),
        'slug' => $this->faker->slug(),
        'excerpt' => $this->faker->paragrph(),
        'body' => $this->faker->paragraph(5,10),
        'user_id' => 1,
        'category_id' => 1
        //
    ];
});
