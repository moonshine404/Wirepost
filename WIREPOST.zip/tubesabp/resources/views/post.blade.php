@extends('layouts.navbarmain')

@section('container')
<div class="container">
    <div class="row justify-content-center mb-5">
        <div class="col-md-8">
            <h1 class="mb-3">{{ $post->title }}</h1>
            <p>By. <a href="/authors/{{ $post->author->username }}" class='text-decoration-none'>{{ $post->author->name }}</a> in <a class='text-decoration-none' href="/categories/{{ $post->category->slug }}">{{ $post->category->name }}</a></p>
            
            <img src="{{ asset('storage/' . $post->image) }}" alt="">
            
            <article class="my-3 fs-5">
                {!! $post->body !!}
            </article>
            <form action="/posts/{{ $post->slug }}" method="post" class="d-inline">
                @method('delete')
                @csrf
                <button class="text-decoration-none btn btn-danger" onclick="return confirm('Are you sure?')"><span data-feather='x-circle'>DELETE</span></button>
            </form>
        
            <a href="/posts" class='text-decoration-none btn btn-primary'>Back to Posts</a>
        </div>
    </div>
</div>
@endsection