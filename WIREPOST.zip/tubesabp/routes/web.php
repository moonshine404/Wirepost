<?php

use App\Post;
use App\User;
use App\Category;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ContentController;
use App\Http\Controllers\RegisterController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/wirepost', function () {
    return view('loginpage', [
        "title" => "Welcome"
    ]);
});
Route::get('/upload', function () {
    return view('upload', [
        "title" => "Upload",
        "active" => 'upload',
    ]);
});
Route::get('/categories', function () {
    return view('categories', [
        "title" => "Categories"
    ]);
});
Route::get('/posts', [PostController::class, 'index']);
//halaman single post
Route::get('posts/{post:slug}', [PostController::class, 'show']);

Route::post('/register', [RegisterController::class, 'store']);
Route::post('/login', [LoginController::class, 'authenticate']);

Route::get('/categories', function(){
    return view('categories', [
        'title' => 'Post Categories',
        "active" => 'categories',
        'categories' => Category::all()
    ]);  
});
Route::get('/categories/{category:slug}', function(Category $category){
    return view('posts', [
        'title' => "Post by Category : $category->name",
        "active" => 'categories',
        'posts' => $category->posts,
        'category'=> $category->name
    ]);
});
Route::get('/authors/{author:username}', function(User $author){
    return view('posts', [
        'title' => "Post by Author : $author->name",
        'posts' => $author->posts
    ]);
});

Route::post('/upload/uploaded', [ContentController::class, 'store']);
Route::get('/upload/checkSlug', [ContentController::class, 'checkSlug']);