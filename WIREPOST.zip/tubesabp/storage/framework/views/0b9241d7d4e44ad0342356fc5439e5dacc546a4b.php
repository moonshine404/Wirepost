

<?php $__env->startSection('container'); ?>
<h1 class="mb-5"><?php echo e($title); ?></h1>

<?php if($posts->count()): ?>
    <div class="card mb-3">
      <?php if($posts[0]->image): ?>
        <div style="max-height: 350px; overflow:hidden;">
          <img src="<?php echo e(asset('storage/' . $posts[0]->image)); ?>" class="card-img-top" alt=""></div>
      <?php endif; ?>
        <div class="card-body text-center">
          <h3 class="card-title"><a class="text-decoration-none text-dark" href="/posts/<?php echo e($posts[0]->slug); ?>"><?php echo e($posts[0]->title); ?></a></h3>
          <p>
            <small class="text-muted">
                By. <a href="/authors/<?php echo e($posts[0]->author->username); ?>" class='text-decoration-none'><?php echo e($posts[0]->author->name); ?></a> in <a class='text-decoration-none' href="/categories/<?php echo e($posts[0]->category->slug); ?>">
                <?php echo e($posts[0]->category->name); ?></a>
                
            </small>
        </p>
        
        
        
        <p class="card-text"><?php echo e($posts[0]->excerpt); ?></p>

        <a class='text-decoration-none btn btn-primary' href="/posts/<?php echo e($posts[0]->slug); ?>">Read more</a>
        </div>
      </div>
<?php else: ?>
    <p class="text-center fs-4">No post found</p>
<?php endif; ?>

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="position-absolute bg-dark px-3 py-2 text-white" style="background-color: rgba(0, 0, 0, 0.7)"><a class="text-decoration-none text-white" href="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a></div>
                <img src="<?php echo e(asset('storage/' . $posts[1]->image)); ?>" class="card-img-top" alt="">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($post->title); ?></h5>
                  <p>
                    <small class="text-muted">
                        By. <a href="/authors/<?php echo e($post->author->username); ?>" class='text-decoration-none'><?php echo e($post->author->name); ?></a>
                        
                    </small>
                </p>
                  <p class="card-text"><?php echo e($post->excerpt); ?></p>
                  <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-primary">Read more</a>
                </div>
              </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/posts.blade.php ENDPATH**/ ?>