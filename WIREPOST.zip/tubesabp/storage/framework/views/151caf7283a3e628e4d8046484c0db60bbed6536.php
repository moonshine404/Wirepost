<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>   
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/homestyle.css">
</head>

<body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="sr-only icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li role="presentation" ><a href="#"><img src="img/triple bullet.png" alt="" height="40" style="margin:auto; padding-top:10px; padding-bottom:10px;"></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-left">
                    
                    <li role="presentation" style="font-size:60px;color:#118941;">WIREP<img src="img/wirepostlogo.png" alt="" width="50" class="center1" style="margin:auto; padding-right:1px; padding-bottom:10px; padding-left:1px;">ST</li>
                    <li></p></li>
                </ul>
            </div>
        </div>
        <div style=background-color:#118941><p>.</p></div>
    </nav>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<div class="container-fluid" style="font-style: arial;">
    <p>.</p>
    <br><br><br><br><br>
    <div class="row">
        <div class="col-sm-2"><p>KOMODO ISLAND</p></div>
        <div class="col-sm-10" style="background-color:#808080; border-radius: 15px 0px 0px 0px; height:40px;"></div>
    </div>
    <div class="row">
        <div class="col-sm-2"><p></p></div>
        <div class="col-sm-10" style="background-color:#808080;">
            <div class="col-sm-3"><img src="img/IMG_01042020_115809__822_x_430_piksel_.jpg"  height="150" ></div>
            <div class="col-sm-3"><img src="img/Komodo_Island_2009.jpg"  height="150" ></div>
            <div class="col-sm-3"><img src="img/komodoilnd.jpg"  height="150" ></div>
            <div class="col-sm-3"><img src="img/Pulau-rinca.jpg"  height="150" ></div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-2"><p></p></div>
        <div class="col-sm-10" style="background-color:#808080; ">
            <div class="col-sm-3">user1 <br> caption1</div>
            <div class="col-sm-3">user2 <br> caption2</div>
            <div class="col-sm-3">user3 <br> caption3</div>
            <div class="col-sm-3">user4 <br> caption4</div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-2"><p></p></div>
        <div class="col-sm-10" style="background-color:#808080; border-radius: 0px 0px 0px 15px; height: 40px;"></div>
    </div>
</div>
    
    
</body>
</html><?php /**PATH C:\xampp\htdocs\tubesabp\resources\views/homepage.blade.php ENDPATH**/ ?>