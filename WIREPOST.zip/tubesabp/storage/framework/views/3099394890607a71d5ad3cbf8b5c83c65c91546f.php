

<?php $__env->startSection('container'); ?>
<h1>My Article</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/myarticle.blade.php ENDPATH**/ ?>