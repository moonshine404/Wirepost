

<?php $__env->startSection('container'); ?>

<style>
    
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }
    
    .drag-area{
        border: 2px solid #000;
        height: 500px;
        width: 65%;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        margin-left: auto;
        margin-right: auto;
    }
    .drag-area.active{
        border: 2px solid #000;
    }
    .drag-area .icon{
        font-size: 100px;
        color: #000;
    }
    .drag-area span{
        font-size: 25px;
        font-weight: 500;
        color: #000;
        margin: 10px 0 15px 0;
    }
    .drag-area button{
        padding: 10px 25px;
        font-size: 20px;
        font-weight: 500;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        cursor: pointer;
    }
    .drag-area img{
        height: 100%;
        width: 100%;
        object-fit: cover;
        border-radius: 5px;
    }
    div.justified {
        display: flex;
        justify-content: center;
    }
    textarea.til {
        width: 80%;
        height: 55px;
        padding: 12px 20px;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        background-color: #f8f8f8;
        font-size: 16px;
        resize: none;
    }
    textarea.desc {
        width: 100%;
        height: 150px;
        padding: 12px 20px;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        background-color: #f8f8f8;
        font-size: 16px;
        resize: none;
    }
    .dropbtn {
        background-color: #4CAF50;
        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
        cursor: pointer;
    }
    
    .dropdown {
        position: relative;
        display: inline-block;
    }
    
    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }
    
    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }
    
    .dropdown-content a:hover {background-color: #f1f1f1}
    
    .dropdown:hover .dropdown-content {
        display: block;
    }
    
    .dropdown:hover .dropbtn {

        background-color: #3e8e41;
    }

</style>


<h1>Make Your Post Here</h1>
<form method="post" action="/upload/uploaded" class="mb-5" enctype="multipart/form-data">
    <br>
    <div class="mb-3">
        <label for="title" class="form-label">Title</label>
        <br>
        <input type ="text" class="form-control" id="title" name="title"></textarea><br><br>
    </div>
    <div class="mb-3">
        <label for="slug" class="form-label">Slug</label>
        <br>
        <input type="text" class="form-control" id="slug" name="slug"></textarea><br><br>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Category ID</label>
        <br>
        <select class="form-select" name="category_id">
            <option value=1>Pegunungan</option>
            <option value=2>Pantai</option>
            <option value=3>Kuliner</option>
        </select>
        <br><br>
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Add your picture</label>
        <input class="form-control" type="file" id="image" name="image">
    </div>
    <div class="mb-3">
        <label for="body" class="form-label">Body</label>
        <br>
        <input id="body" type="hidden" name="body">
        <trix-editor input="body"></trix-editor>
        <br><br>
    </div>

    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div class="justified"><button style="color:#fff;font-size: 30px; background-color: #4CAF50;border-radius: 8px;padding: 12px 28px;">UPLOAD</button></div>
    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div><br></div>
    <div class="justified" >
        wirepost
    </div>
    
</form>
<script>
    const title - document.querySelector('#title');
    const title - document.querySelector('#slug');

    title.addEventListener('change', function(){
        fetch('upload/checkSlug?title=' + title.value)
            .then(response => response.json())
            .then(data => slug.value = data.slug)
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/upload.blade.php ENDPATH**/ ?>