<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!--Trix Editor-->
    <link rel="stylesheet" type="text/css" href="/css/trix.css">
    <script type="text/javascript" src="/js/trix.js"></script>
    
    <title>WirePost | <?php echo e($title); ?></title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
          <a class="navbar-brand" href="/posts"><img src="img/wirepostlogo.png" alt="" width="50" style="margin:auto; padding-right:1px; padding-bottom:10px; padding-left:1px;">WirePost</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link <?php echo e(($active === "posts") ? 'active' : ''); ?>" href="/posts">Posts</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(($active === "categories") ? 'active' : ''); ?>" href="/categories">Categories</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(($active === "upload") ? 'active' : ''); ?>" href="/upload">Upload</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(($active === "logout") ? 'active' : ''); ?>" href="/wirepost">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="container mt-4">
        <?php echo $__env->yieldContent('container'); ?>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/layouts/navbarmain.blade.php ENDPATH**/ ?>