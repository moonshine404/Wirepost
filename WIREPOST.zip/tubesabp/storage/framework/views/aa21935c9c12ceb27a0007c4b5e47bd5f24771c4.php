

<?php $__env->startSection('container'); ?>
<h1>Home</h1>
<div class="container-fluid" style="font-style: arial;">
    <div class="row">
        <div class="col-sm-2"><p>KOMODO ILAND</p></div>
        <div class="col-sm-10" style="background-color:#808080; border-radius: 15px 0px 0px 0px; height:40px;"></div>
    </div>
<div class="row">
    <div class="col-sm-2"><p></p></div>
    <div class="col-sm-10" style="background-color:#808080;">
        <div class="col-sm-3"><img src="img/IMG_01042020_115809__822_x_430piksel.jpg"  height="150" ></div>
        <div class="col-sm-3"><img src="img/Komodo_Island_2009.jpg"  height="150" ></div>
        <div class="col-sm-3"><img src="img/komodoilnd.jpg"  height="150" ></div>
        <div class="col-sm-3"><img src="img/Pulau-rinca.jpg"  height="150" ></div>
    </div>
</div>
<div class="row">
    <div class="col-sm-2"><p></p></div>
    <div class="col-sm-10" style="background-color:#808080; ">
        <div class="col-sm-3">user1 <br> caption1</div>
        <div class="col-sm-3">user2 <br> caption2</div>
        <div class="col-sm-3">user3 <br> caption3</div>
        <div class="col-sm-3">user4 <br> caption4</div>
    </div>
</div>
<div class="row">
    <div class="col-sm-2"><p></p></div>
    <div class="col-sm-10" style="background-color:#808080; border-radius: 0px 0px 0px 15px; height: 40px;"></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/homepage.blade.php ENDPATH**/ ?>