<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wirepost</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <section class="left-section">
        <div id="left-cover" class="cover cover-hide">
            <img src="img/cover2.jfif" alt="">
            <h1>Welcome !</h1>
            <h3>Already have an account ?</h3>
            <button type="button" class="switch-btn" onclick="location.reload()">Login</button>
        </div>
        <div id="left-form" class="form fade-in-element">
            
            <h1><img src="img/wirepostlogo.png"  alt="" width="60">Login</h1>
            <form action="/login" method="post">
                <input type="email" name="email" class="input-box" placeholder="email">
                <input type="password" name="password" class="input-box" placeholder="Password">
                <button  class="btn" type="submit" name="login-btn" value="Login">Login</a>
            </form>
        </div>
    </section>

    <section class="right-section">
        <div id="right-cover" class="cover fade-in-element">
            <img src="img/cover2.jfif" alt="">
            <h1>Welcome !</h1>
            <h3>Don't have an account ?</h3>
            <button type="button" class="switch-btn" onclick="switchSignup()">Signup</button>
        </div>
        <div id="right-form" class="form form-hide">
            <h1><img src="img/wirepostlogo.png" alt="" width="60">Signup</h1>
            <form action="/register" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <input type="text" name="nama" class="input-box" placeholder="Nama">
                <input type="text" name="username" class="input-box" placeholder="User Name">
                <input type="text" name="email" class="input-box" placeholder="Email">
                <input type="password" name="password" class="input-box" placeholder="Password">
                <button class="btn" type="submit" name="signup-btn" value="Signup" href="#">Signup</button>
            </form>
        </div>
    </section>

    <script src="js/main.js"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\tubesabp\resources\views/loginpage.blade.php ENDPATH**/ ?>