

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row justify-content-center mb-5">
        <div class="col-md-8">
            <h1 class="mb-3"><?php echo e($post->title); ?></h1>
            <p>By. <a href="/authors/<?php echo e($post->author->username); ?>" class='text-decoration-none'><?php echo e($post->author->name); ?></a> in <a class='text-decoration-none' href="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a></p>
            
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="">
            
            <article class="my-3 fs-5">
                <?php echo $post->body; ?>

            </article>
            <form action="/posts/<?php echo e($post->slug); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="text-decoration-none btn btn-danger" onclick="return confirm('Are you sure?')"><span data-feather='x-circle'>DELETE</span></button>
            </form>
        
            <a href="/posts" class='text-decoration-none btn btn-primary'>Back to Posts</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/post.blade.php ENDPATH**/ ?>