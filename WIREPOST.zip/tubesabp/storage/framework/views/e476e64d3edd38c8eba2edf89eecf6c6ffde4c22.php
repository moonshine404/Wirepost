

<?php $__env->startSection('container'); ?>
<h1 class="mb-5">Post Category : <?php echo e($category); ?></h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article>
        <h2>
            <a class='text-decoration-none' href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a>
        </h2>
        <P><?php echo e($post->excerpt); ?></P>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="/posts" class='text-decoration-none'>Back to Posts</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbarmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fahmi\File Kuliah\Tingkat Tiga\Semester 6\Aplikasi Berbasis Platform\TUBES\tubesabp_up_loginregister_done\tubesabp\resources\views/category.blade.php ENDPATH**/ ?>